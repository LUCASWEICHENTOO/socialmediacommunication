import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema(
  {
    username: { type: String, unique: true, index: true },
    passwordHash: String
  },
  { timestamps: true }
);

const FriendshipSchema = new mongoose.Schema(
  {
    requester: { type: mongoose.Types.ObjectId, ref: 'User', index: true },
    addressee: { type: mongoose.Types.ObjectId, ref: 'User', index: true },
    status: { type: String, enum: ['pending', 'accepted', 'rejected'], default: 'pending', index: true }
  },
  { timestamps: true }
);

const MessageSchema = new mongoose.Schema(
  {
    from: { type: mongoose.Types.ObjectId, ref: 'User', index: true },
    to: { type: mongoose.Types.ObjectId, ref: 'User', index: true },
    text: String
  },
  { timestamps: { createdAt: 'createdAt', updatedAt: false } }
);

export const User = mongoose.model('User', UserSchema);
export const Friendship = mongoose.model('Friendship', FriendshipSchema);
export const Message = mongoose.model('Message', MessageSchema);
