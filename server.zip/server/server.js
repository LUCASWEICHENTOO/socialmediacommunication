import 'dotenv/config';
import express from 'express';
import http from 'http';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Server as SocketIOServer } from 'socket.io';
import mongoose from 'mongoose';
import { User, Friendship, Message } from './models.js';

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: '*', methods: ['GET', 'POST'] } });

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/convo';
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// root — health check
app.get('/', (_req, res) => res.json({ ok: true }));

// helpers
function makeToken(user) {
  return jwt.sign({ uid: user._id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
}
function auth(req, res, next) {
  const hdr = req.headers.authorization || '';
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'invalid token' });
  }
}

// auth routes
app.post('/auth/register', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'username & password required' });
  const exists = await User.findOne({ username: username.toLowerCase() });
  if (exists) return res.status(409).json({ error: 'username taken' });
  const hash = await bcrypt.hash(password, 10);
  const user = await User.create({ username: username.toLowerCase(), passwordHash: hash });
  return res.json({ token: makeToken(user), user: { id: user._id, username: user.username } });
});

app.post('/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  const user = await User.findOne({ username: username?.toLowerCase() });
  if (!user) return res.status(401).json({ error: 'invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'invalid credentials' });
  return res.json({ token: makeToken(user), user: { id: user._id, username: user.username } });
});

app.get('/me', auth, async (req, res) => {
  const me = await User.findById(req.user.uid).select('_id username');
  res.json({ user: me });
});

// friends
app.post('/friends/request', auth, async (req, res) => {
  const { toUsername } = req.body || {};
  const to = await User.findOne({ username: toUsername?.toLowerCase() });
  if (!to) return res.status(404).json({ error: 'user not found' });
  if (to._id.equals(req.user.uid)) return res.status(400).json({ error: 'cannot add yourself' });

  const dup = await Friendship.findOne({
    $or: [
      { requester: req.user.uid, addressee: to._id },
      { requester: to._id, addressee: req.user.uid }
    ]
  });
  if (dup && dup.status !== 'rejected') return res.status(409).json({ error: 'already requested or friends' });

  const fr = await Friendship.create({ requester: req.user.uid, addressee: to._id, status: 'pending' });
  io.to(String(to._id)).emit('friend:request', { from: req.user.uid });
  res.json({ ok: true, request: fr });
});

app.post('/friends/accept', auth, async (req, res) => {
  const { requesterId } = req.body || {};
  const fr = await Friendship.findOneAndUpdate(
    { requester: requesterId, addressee: req.user.uid, status: 'pending' },
    { status: 'accepted' },
    { new: true }
  );
  if (!fr) return res.status(404).json({ error: 'request not found' });
  io.to(String(requesterId)).emit('friend:accepted', { by: req.user.uid });
  res.json({ ok: true, friendship: fr });
});

app.post('/friends/reject', auth, async (req, res) => {
  const { requesterId } = req.body || {};
  const fr = await Friendship.findOneAndUpdate(
    { requester: requesterId, addressee: req.user.uid, status: 'pending' },
    { status: 'rejected' },
    { new: true }
  );
  if (!fr) return res.status(404).json({ error: 'request not found' });
  res.json({ ok: true });
});

app.get('/friends', auth, async (req, res) => {
  const uid = req.user.uid;
  const rows = await Friendship.find({ status: 'accepted', $or: [{ requester: uid }, { addressee: uid }] })
    .populate('requester', 'username')
    .populate('addressee', 'username');
  const friends = rows.map(r => {
    const f = r.requester._id.equals(uid) ? r.addressee : r.requester;
    return { id: f._id, username: f.username };
  });
  res.json({ friends });
});

app.get('/friends/pending', auth, async (req, res) => {
  const uid = req.user.uid;
  const inbound = await Friendship.find({ addressee: uid, status: 'pending' }).populate('requester', 'username');
  const outbound = await Friendship.find({ requester: uid, status: 'pending' }).populate('addressee', 'username');
  res.json({
    inbound: inbound.map(r => ({ requesterId: r.requester._id, requesterName: r.requester.username })),
    outbound: outbound.map(r => ({ addresseeId: r.addressee._id, addresseeName: r.addressee.username }))
  });
});

// messages
app.get('/messages/:friendId', auth, async (req, res) => {
  const uid = req.user.uid;
  const fid = req.params.friendId;
  const msgs = await Message.find({
    $or: [{ from: uid, to: fid }, { from: fid, to: uid }]
  })
    .sort({ createdAt: -1 })
    .limit(50);
  res.json({ messages: msgs.reverse() });
});

// socket auth
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('no token'));
  try {
    socket.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    next(new Error('bad token'));
  }
});

// sockets
io.on('connection', socket => {
  const uid = String(socket.user.uid);
  socket.join(uid);

  socket.on('dm:send', async ({ to, text }) => {
    if (!to || !text) return;
    const msg = await Message.create({ from: uid, to, text });
    io.to(uid).emit('dm:new', msg);
    io.to(String(to)).emit('dm:new', msg);
  });
});

// connect & listen
mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB connected:', MONGO_URI);
    server.listen(PORT, () => console.log('✅ Server running on :' + PORT));
  })
  .catch(err => {
    console.error('❌ MongoDB connection error:', err.message);
    process.exit(1);
  });
