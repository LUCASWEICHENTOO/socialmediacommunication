import React, { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { API_BASE, get, post } from './api';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [me, setMe] = useState(null);
  const [friends, setFriends] = useState([]);
  const [pending, setPending] = useState({ inbound: [], outbound: [] });
  const [activeFriend, setActiveFriend] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const socketRef = useRef(null);

  // fetch /me after login
  useEffect(() => {
    if (token) get('/me', token).then(({ user }) => setMe({ id: user._id, username: user.username })).catch(() => setMe(null));
  }, [token]);

  // connect socket when authenticated
  useEffect(() => {
    if (!token) return;
    const s = io(API_BASE, { auth: { token } });
    socketRef.current = s;

    s.on('dm:new', msg => {
      setMessages(prev => {
        if (!activeFriend) return prev;
        const belongs =
          (msg.from === me?.id && msg.to === activeFriend?.id) ||
          (msg.from === activeFriend?.id && msg.to === me?.id);
        return belongs ? [...prev, msg] : prev;
      });
    });
    s.on('friend:request', () => {
      fetchFriends();
      fetchPending();
    });
    s.on('friend:accepted', () => {
      fetchFriends();
      fetchPending();
    });

    return () => s.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, me, activeFriend]);

  async function fetchFriends() {
    const { friends } = await get('/friends', token);
    setFriends(friends);
  }
  async function fetchPending() {
    const data = await get('/friends/pending', token);
    setPending(data);
  }
  async function fetchThread(fid) {
    const { messages } = await get(`/messages/${fid}`, token);
    setMessages(messages);
  }

  async function afterLogin(t, u) {
    setToken(t);
    localStorage.setItem('token', t);
    setMe({ id: u.id, username: u.username });
    await Promise.all([fetchFriends(), fetchPending()]);
  }

  async function handleSend() {
    const trimmed = text.trim();
    if (!trimmed || !activeFriend) return;
    socketRef.current?.emit('dm:send', { to: activeFriend.id, text: trimmed });
    setText('');
  }

    // ✅ PUT LOGOUT INSIDE THE COMPONENT
  function logout() {
    try { socketRef.current?.disconnect(); } catch {}
    localStorage.removeItem('token');
    setToken('');
    setMe(null);
    setFriends([]);
    setPending({ inbound: [], outbound: [] });
    setActiveFriend(null);
    setMessages([]);
  }


  if (!token || !me) {
    return <Auth onAuthed={afterLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 grid grid-cols-12">
      <aside className="col-span-4 border-r border-slate-200 p-3 bg-white space-y-4">
       <div className="flex items-center justify-between">
  <div className="font-semibold">👤 {me.username}</div>
  <button
    onClick={logout}
    className="text-xs px-2 py-1 rounded-md border border-slate-300 hover:bg-slate-100"
    title="Log out"
  >
    Log out
  </button>
</div>

        <FriendAdd token={token} onChange={() => fetchPending()} />
        <FriendRequests token={token} pending={pending} onChange={() => { fetchFriends(); fetchPending(); }} />
        <div>
          <div className="text-xs uppercase tracking-wide text-slate-500">Friends</div>
          <ul className="mt-2 space-y-1 max-h-[40vh] overflow-auto pr-1">
            {friends.map(f => (
              <li key={f.id}>
                <button
                  onClick={() => { setActiveFriend(f); fetchThread(f.id); }}
                  className={`w-full text-left px-3 py-2 rounded-md ${activeFriend?.id === f.id ? 'bg-amber-100' : 'hover:bg-slate-100'}`}
                >
                  {f.username}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </aside>

      <main className="col-span-8 flex flex-col">
        <header className="p-3 border-b bg-white">
          {activeFriend ? `Chat with ${activeFriend.username}` : 'Pick a friend to start chatting'}
        </header>

        <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-[linear-gradient(180deg,#fff,rgba(250,250,250,.9))]">
          {messages.map(m => (
            <div
              key={m._id}
              className={`max-w-[70%] px-3 py-2 rounded-2xl text-sm shadow ${m.from === me.id ? 'ml-auto bg-amber-200/80' : 'bg-white border'}`}
            >
              {m.text}
              <div className="text-[10px] opacity-60 mt-1 text-right">
                {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          ))}
        </div>

        <div className="p-3 border-t bg-white flex gap-2">
          <input
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') handleSend(); }}
            className="flex-1 border rounded-xl px-3 py-2"
            placeholder="Type a message"
          />
          <button onClick={handleSend} className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-500">Send</button>
        </div>
      </main>
    </div>
  );
}


function Auth({ onAuthed }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState('login');
  const [error, setError] = useState('');

  async function submit() {
    setError('');
    try {
      const path = mode === 'login' ? '/auth/login' : '/auth/register';
      const { token, user } = await post(path, { username, password });
      await onAuthed(token, user);
    } catch (e) {
      setError(e.message || 'Failed to fetch');
    }
  }

  return (
    <div className="min-h-screen grid place-items-center bg-slate-50">
      <div className="w-full max-w-sm bg-white p-6 rounded-2xl border shadow">
        <div className="text-lg font-semibold mb-2">Realtime Chat</div>
        <div className="text-sm opacity-70 mb-4">{mode === 'login' ? 'Login' : 'Create account'}</div>

        <input className="w-full border rounded-md px-3 py-2 mb-2" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
        <input type="password" className="w-full border rounded-md px-3 py-2 mb-3" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
        {error && <div className="text-red-600 text-sm mb-2">{error}</div>}

        <button onClick={submit} className="w-full rounded-md bg-amber-400 hover:bg-amber-500 py-2">{mode === 'login' ? 'Login' : 'Sign up'}</button>

        <div className="text-xs mt-3 text-center">
          {mode === 'login' ? (
            <button className="underline" onClick={() => setMode('register')}>Create an account</button>
          ) : (
            <button className="underline" onClick={() => setMode('login')}>I have an account</button>
          )}
        </div>
      </div>
    </div>
  );
}

function FriendAdd({ token, onChange }) {
  const [name, setName] = useState('');
  const [err, setErr] = useState('');
  async function add() {
    setErr('');
    if (!name.trim()) return;
    try {
      await post('/friends/request', { toUsername: name.trim() }, token);
      setName('');
      onChange?.();
    } catch (e) { setErr(e.message); }
  }
  return (
    <div>
      <div className="text-xs uppercase tracking-wide text-slate-500 mb-1">Add friend</div>
      <div className="flex gap-2">
        <input value={name} onChange={e => setName(e.target.value)} className="flex-1 border rounded-md px-2 py-1" placeholder="Username" />
        <button onClick={add} className="px-3 py-1 rounded-md bg-slate-900 text-white">Add</button>
      </div>
      {err && <div className="text-red-600 text-xs mt-1">{err}</div>}
    </div>
  );
}

function FriendRequests({ token, pending, onChange }) {
  const [err, setErr] = useState('');

  async function refresh() {
    try { onChange?.(); } catch {}
  }
  async function accept(requesterId) {
    setErr('');
    try { await post('/friends/accept', { requesterId }, token); onChange?.(); } catch (e) { setErr(e.message); }
  }
  async function reject(requesterId) {
    setErr('');
    try { await post('/friends/reject', { requesterId }, token); onChange?.(); } catch (e) { setErr(e.message); }
  }
  return (
    
    <div>
      
      <div className="text-xs uppercase tracking-wide text-slate-500">Requests</div>
      <div className="mt-1 space-y-1 max-h-32 overflow-auto pr-1">
        {pending.inbound.length === 0 && pending.outbound.length === 0 && (
          <div className="text-xs opacity-60">No pending requests</div>
        )}
        {pending.inbound.map(r => (
          <div key={r.requesterId} className="flex items-center justify-between bg-slate-100 rounded-md px-2 py-1 text-sm">
            <span>From <b>{r.requesterName}</b></span>
            <div className="flex gap-2">
              <button onClick={() => accept(r.requesterId)} className="px-2 py-0.5 rounded bg-emerald-500 text-white text-xs">Accept</button>
              <button onClick={() => reject(r.requesterId)} className="px-2 py-0.5 rounded bg-rose-500 text-white text-xs">Reject</button>
            </div>
          </div>
        ))}
        {pending.outbound.map(r => (
          <div key={r.addresseeId} className="flex items-center justify-between bg-white border rounded-md px-2 py-1 text-xs">
            <span>To <b>{r.addresseeName}</b> • pending…</span>
          </div>
        ))}
        {err && <div className="text-red-600 text-xs">{err}</div>}
      </div>
    </div>
  );
}

