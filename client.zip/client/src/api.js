export const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

export function authHeaders(token) {
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function post(path, body, token) {
  const r = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders(token) },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw new Error((await r.json()).error || 'request failed');
  return r.json();
}

export async function get(path, token) {
  const r = await fetch(`${API_BASE}${path}`, { headers: { ...authHeaders(token) } });
  if (!r.ok) throw new Error((await r.json()).error || 'request failed');
  return r.json();
}
